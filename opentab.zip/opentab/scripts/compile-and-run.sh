#!/bin/bash

javac -d bin -cp "opencv_min/opencv-440.jar" ./src/image_processing/*.java ./src/utils/*.java ./src/ui/components/*.java ./src/ui/utils/*.java ./src/state/*.java && java -classpath "./bin:./opencv_min/opencv-440.jar" -Djava.library.path="./opencv_min/macOSx86" ui.components.MainUI